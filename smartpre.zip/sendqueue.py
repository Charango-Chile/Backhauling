#!/usr/bin/env python

import pika
import json
from smart.models import State

def sendmessageParcel(id, shippingAddressLatitude, shippingAddressLongitude, weight,  productType,
                      shippingRate, status):

    state = State.objects.get(key='ProcessQueue')
    queque_name = 'Backhaul'+str(state.value)
    if state.value == 1:
        State.objects.filter(id=state.id).update(value=2)
    else:
        State.objects.filter(id=state.id).update(value=1)

    msj = {'typeMessage': 'parcel','id': id, 'shippingAddressLatitude': shippingAddressLatitude,
           'shippingAddressLongitude': shippingAddressLongitude,
           'weight': weight, 'productType': productType, 'shippingRate': shippingRate, 'status':status, }
    msjason = json.dumps(msj)
    connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()
    channel.queue_declare(queue=queque_name, durable=True)
    channel.basic_publish(exchange='queque_name', routing_key=queque_name, body=msjason, properties=pika.BasicProperties(delivery_mode = 2))
    connection.close()

def sendMessageOptimization():
    state = State.objects.get(Key='ProcessQueue')
    queque_name = 'Backhaul'+str(state.value)
    if state.value == 1:
        State.objects.filter(id=state.id).update(value=2)
    else:
        State.objects.filter(id=state.id).update(value=1)
    msj = {'typeMessage': 'optimisation'}
    msjason = json.dumps(msj)
    connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()
    channel.queue_declare(queue=queque_name, durable=True)
    channel.basic_publish(exchange='queque_name', routing_key=queque_name, body=msjason, properties=pika.BasicProperties(delivery_mode = 2))
    connection.close()

def sendmessageTruck(id, garageLatitude, garageLongitude,  truckTypeDescriptionType, truckTypeCost,
                     truckTypeMaximunWeight, status):

    state = State.objects.get(key='ProcessQueue')
    queque_name = 'Backhaul'+str(state.value)
    if state.value == 1:
        State.objects.filter(id=state.id).update(value=2)
    else:
        State.objects.filter(id=state.id).update(value=1)
    connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))

    channel = connection.channel()

    channel.queue_declare(queue=queque_name, durable=True)
    msj = {'typeMessage': 'truck', 'id': id, 'Garage_Latitude': garageLatitude, 'Garage_Longitude':garageLongitude,
           'truckType_description_Type': truckTypeDescriptionType, 'truckType_cost': truckTypeCost,
           'truckType_maximun_Weight': truckTypeMaximunWeight,'status': status,
           }
    msjason = json.dumps(msj)
    channel.basic_publish(exchange='', routing_key=queque_name, body=msjason, properties=pika.BasicProperties(delivery_mode = 2))
    connection.close()



