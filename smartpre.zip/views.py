# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from .sendqueue import sendmessageParcel, sendmessageTruck, sendMessageOptimization
from django.views.generic.edit import UpdateView, CreateView
from django.views.generic.list import ListView
from smart.forms import TruckForm, DriverForm, PackageForm
from smart.models import Truck, Driver, Package, Route
from django.urls import reverse_lazy
from django.views.generic.detail import DetailView
from django.http.response import HttpResponseRedirect
from django.views.generic.base import TemplateView
from django.http import JsonResponse

from django.contrib.auth.views import LoginView, LogoutView


class DashboardCarrier(TemplateView):
    template_name = 'dashboadcarrier.html'


class DashboardShipper(TemplateView):
    template_name = 'dashboadshipper.html'


class DashboardAdmin(TemplateView):
    template_name = 'dashboadadmin.html'


class TruckDeal(TemplateView):
    template_name = 'truckdeal.html'

    def post(self, request, **kwargs):
        Truck.objects.filter(id=4).update(status=True)
        return HttpResponseRedirect(self.success_url)

    def activetruck(self):
        if self.request.user.has_perm('smart.admin'):
                trucks = Truck.objects.filter(proposed=False, acepted=False)
        else:
                trucks = Truck.objects.filter(user=self.request.user, proposed=False, acepted=False)
        return trucks

    def proposeddeal(self):
        if self.request.user.has_perm('smart.admin'):
                routes = Route.objects.filter(status=1)
        else:
            routes = Route.objects.filter(status=1, user=self.request.user)

        return routes

    def accepteddeal(self):
        if self.request.user.has_perm('smart.admin'):
                routes = Route.objects.filter(status=2)
        else:
            routes = Route.objects.filter(status=2, user=self.request.user)
        return routes


class RouteDetail(DetailView):
    model = Route
    template_name = 'route_detail.html'


class ParcelDetail(DetailView):
    model = Package
    template_name = 'parcel_detail.html'


class DeliveryDeal(TemplateView):
    template_name = 'deliverydeal.html'

    def availableParcel(self):
        if self.request.user.has_perm('smart.admin'):
            packages = Package.objects.filter(status=1)
        else:
            packages = Package.objects.filter(user=self.request.user,status=1)
        return packages

    def proposedParcel(self):
        if self.request.user.has_perm('smart.admin'):
            packages = Package.objects.filter(status=2)
        else:
            packages = Package.objects.filter(user=self.request.user, status=2)

        return packages




# Login  Views
class LoginSmart(LoginView):
    template_name = 'login.html'
    next_page = 'welcome.html'


class LogoutSmart(LogoutView):
    template_name = 'logout.html'


class Index(TemplateView):
    template_name = 'index.html'


class Welcome(TemplateView):
    template_name = 'welcome.html'

# Truck Views
class TruckList(ListView):
        model = Truck
        template_name = 'trucks.html'
        context_object_name = 'trucks'

        def get_queryset(self):
                if self.request.user.has_perm('smart.admin'):
                    queryset = super(TruckList, self).get_queryset()
                    queryset = queryset.filter(is_Deleted=False)
                else:
                    queryset = super(TruckList, self).get_queryset()
                    queryset = queryset.filter(user=self.request.user, is_Deleted=False)
                return queryset


class CreateTruck(CreateView):
    form_class = TruckForm
    template_name = 'truck.html'
    success_url = reverse_lazy('truck_list')

    def post(self, request, *args, **kwargs):
        form_class = self.get_form_class()
        form = self.get_form(form_class)
        if form.is_valid():
            truck = form.save(commit=False)
            truck.user = request.user


            truck.Garage_Longitude = request.POST['Garage_Latitude']
            truck.Garage_Latitude = request.POST['Garage_Latitude']

            truck.save()
            if truck.status:
                sendmessageTruck(truck.id, truck.Garage_Latitude, truck.Garage_Longitude,
                                 truck.truck_Type.description_Type, truck.truck_Type.cost,
                                 truck.truck_Type.maximum_Weight, truck.status)

            return HttpResponseRedirect(self.success_url)


class UpdateTruck(UpdateView):
    model = Truck

    template_name = 'truck.html'
    form_class = TruckForm
    success_url = reverse_lazy('truck_list')

    def form_valid(self, form):
       truck = form.save(commit=False)
       truck.Garage_Longitude = self.request.POST.get('Garage_Longitude', None)
       truck.Garage_Latitude = self.request.POST.get('Garage_Latitude', None)
       if truck.status:
           sendmessageTruck(truck.id, truck.Garage_Latitude, truck.Garage_Longitude,
                            truck.truck_Type.description_Type, truck.truck_Type.cost,
                            truck.truck_Type.maximum_Weight,  truck.status)
       self.object.save()
       return HttpResponseRedirect(self.success_url)


class TruckDetail(DetailView):
    model = Truck
    template_name = 'truck_detail.html'


class TruckDelete(DetailView):
    model = Truck
    template_name = 'truck_delete.html'
    form_class = TruckForm
    success_url = reverse_lazy('truck_list')

    def post(self, request, *args, **kwargs):
        Truck.objects.filter(id=kwargs['pk']).update(is_Deleted=True)
        return HttpResponseRedirect(self.success_url)


# Driver Views
class DriverList(ListView):
    model = Driver
    template_name = 'drivers.html'
    context_object_name = 'drivers'

    def get_queryset(self):
        queryset = super(DriverList, self).get_queryset()
        queryset = queryset.filter(user=self.request.user, is_Deleted=False)
        return queryset


class CreateDriver(CreateView):
    form_class = DriverForm
    template_name = 'driver.html'
    success_url = reverse_lazy('driver_list')

    def post(self, request, *args, **kwargs):
        form_class = self.get_form_class()
        form = self.get_form(form_class)
        if form.is_valid():
            driver = form.save(commit=False)
            driver.user = request.user
            driver.save()
            return HttpResponseRedirect(self.success_url)


class UpdateDriver(UpdateView):
    model = Driver
    template_name = 'driver.html'
    form_class = DriverForm
    success_url = reverse_lazy('driver_list')


class DriverDetail(DetailView):
    model = Driver
    template_name = 'driver_detail.html'


class DriverDelete(UpdateView):
    model = Driver
    template_name = 'driver_delete.html'
    form_class = DriverForm
    success_url = reverse_lazy('driver_list')

    def post(self, request, *args, **kwargs):
        Driver.objects.filter(id=kwargs['pk']).update(is_Deleted=True)
        return HttpResponseRedirect(self.success_url)


# Packages Views
class PackageList(ListView):
    model = Package
    template_name = 'packages.html'
    context_object_name = 'packages'

    def get_queryset(self):
        if self.request.user.has_perm('smart.admin'):
            queryset = super(PackageList, self).get_queryset()
            queryset = queryset.filter(is_Deleted=False)
        else:
            queryset = super(PackageList, self).get_queryset()
            queryset = queryset.filter(user=self.request.user, is_Deleted=False)
        return queryset

        queryset = super(PackageList, self).get_queryset()
        queryset = queryset.filter(user=self.request.user, is_Deleted=False)
        return queryset


class CreatePackage(CreateView):
    form_class = PackageForm
    template_name = 'package.html'
    success_url = reverse_lazy('package_list')

    def post(self, request, *args, **kwargs):
        form_class = self.get_form_class()
        form = self.get_form(form_class)
        if form.is_valid():
            package = form.save(commit=False)
            package.user = request.user
            price = float(self.request.POST.get('price_offer', 0))
            if price > 0:
                package.price_offer = self.request.POST.get('price_offer', 0)
            package.shipping_Address_Longitude = self.request.POST.get('shipping_Address_Longitude', None)
            package.shipping_Address_Latitude = self.request.POST.get('shipping_Address_Latitude', None)
            package.save()

            sendmessageParcel(package.id, package.shipping_Address_Latitude, package.shipping_Address_Longitude,
                              package.weight, package.product_Type.id_Product, package.price_offer,
                              package.status.id_Status,)
            return HttpResponseRedirect(self.success_url)


class UpdatePackage(UpdateView):
    model = Package
    template_name = 'package.html'
    form_class = PackageForm
    success_url = reverse_lazy('package_list')
    def form_valid(self, form):
        package = form.save(commit=False)
        price = float(self.request.POST.get('price_offer', 0))
        if price > 0:
            package.price_offer = self.request.POST.get('price_offer', 0)
        package.shipping_Address_Longitude = self.request.POST.get('shipping_Address_Longitude', None)
        package.shipping_Address_Latitude = self.request.POST.get('shipping_Address_Latitude', None)
        package.save()
        return HttpResponseRedirect(self.success_url)

class PackageDetail(DetailView):
    model = Package
    template_name = 'package_detail.html'


class PackageDelete(UpdateView):
    model = Package
    template_name = 'package_delete.html'
    form_class = PackageForm
    success_url = reverse_lazy('package_list')

    def post(self, request, *args, **kwargs):
        Package.objects.filter(id=kwargs['pk']).update(is_Deleted=True)
        return HttpResponseRedirect(self.success_url)


def change_truck_status(request):
    truckid = request.GET.get('truckid', None)
    truck = Truck.objects.get(id=truckid)
    if truck.status:
        data = {
            'status': Truck.objects.filter(id=truckid).update(status=False)
        }
    else:
        data = {
            'status': Truck.objects.filter(id=truckid).update(status=True)
        }
    return JsonResponse(data)


def accept_proposal_deal(request):
    routeid = request.GET.get('routeid', None)
    print(routeid)
    data = {
        'status': Route.objects.filter(id=routeid).update(status=2)
    }
    route = Route.objects.get(id=routeid)
    Truck.objects.filter(id=route.truck.id).update(proposed=False, acepted=True)
    return JsonResponse(data)


def end_deal(request):
    routeid = request.GET.get('routeid', None)
    print(routeid)
    data = {
        'status': Route.objects.filter(id=routeid).update(status=4)
    }
    route = Route.objects.get(id=routeid)
    Truck.objects.filter(id=route.truck.id).update(proposed=False, acepted=False, status=True)
    return JsonResponse(data)


def run_process(request):
    sendMessageOptimization()
    data = {
        'status': 0
    }
    return JsonResponse(data)
