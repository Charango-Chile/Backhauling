from django.apps import AppConfig


class SmartConfig(AppConfig):
    name = 'smart'
