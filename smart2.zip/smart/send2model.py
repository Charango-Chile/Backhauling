import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "bhsite.settings")
import django
django.setup()

from smart.models import RouteStatus, Truck, Package, Route
from django.utils import timezone

def addRoute(parcelsTour):
    truck = Truck.objects.filter(id=parcelsTour[len(parcelsTour)-1])
    truck.update(status=False)
    status = RouteStatus.objects.filter(id=1)
    route = Route()
    route.user =truck.user
    route.status = status
    route.truck = parcelsTour[len(parcelsTour)-1]
    route_str = ""
    for x in range(1, len(parcelsTour) - 1):
        route_str = route_str + str(parcelsTour[x]) + ";"
    route.route = route_str
    route.created_Date = timezone.now()
    route.save()
    #update packageslist
    for x in range(1, len(parcelsTour) - 1):
        updateParcelStatus(parcelsTour[x],route.id)


def updateTruckStatus(idtruck):
    truck = Truck.objects.filter(id=idtruck)
    truck.update(status=False)

def updateParcelStatus(idPackage,idRoute):
    routeObj = Route.objects.filter(id=idRoute)
    package = Package.objects.filter(id=idPackage)
    package.update(statrouteus=routeObj)
