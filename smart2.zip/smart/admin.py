from django.contrib import admin

# Register your models here.
from .models import Truck, Driver, PackageStatus, ProductType, RouteStatus,TruckType,ShippingPrice

admin.site.register(Truck)
admin.site.register(Driver)
admin.site.register(TruckType)
admin.site.register(ProductType)
admin.site.register(PackageStatus)
admin.site.register(RouteStatus)
admin.site.register(ShippingPrice)