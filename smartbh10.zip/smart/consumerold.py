import pika
import random
import pickle
from pulp import *
import itertools as it
import requests
from .send2model import addRoute

class Items(object):
    _globalCounter = 0


class UnassignedParcels(object):
    def __init__(self):
        self.List = {}

    def AddParcel(self, key, value):
        self.List[key] = value

    def RemoveParcel(self, key):
        del self.List[key]


class UnFullTrucks(object):
    def __init__(self):
        self.List = {}

    def AddTruck(self, key, value):
        self.List[key] = value

    def RemoveTruck(self, key):
        del self.List[key]


class Truck(Items):
    """
    This class implements a Truck object. It takes care of maintaining a list of Trucks and to expose a method to
    calculate the next best for any given truck.

    The Tour list, initially empty, will grow as the algorithm progresses
    """
    _counter = 0

    def __init__(self, cost, capacity, lat, lon):
        self.id = Truck._counter
        self.DbID = 0
        self.GlobalId = Items._globalCounter
        Items._globalCounter += 1
        self.TransportCost = cost # Cost in Baht per Km
        self.Capacity = capacity
        self.Depot = (lat, lon)
        self.Tour = [] # This list will contain the tour of locations to be visited
        Truck._counter += 1
        self.UnusedCapacity = capacity # This indicates how much capacity is available
        self.Preferences = {}
        self.CarriedValue = 0
        self.CurrentTime = 0
        # Compatibility for Transportation
        # Assumption is that a Truck can carry more than one type
        self.TranspCompat = []
        for i in range(5): # Hardcoded now, needs to change later!
            k = random.randint(0, 1)*(i+1)  # decide on a k each time the loop runs
            self.TranspCompat.append(k)

    def CalculateBest(self, unassigned, distances):
        """
        Create a sublist from the dictionary, i.e., filter by key having first component of the tuple being the
        freezone and the truck Depot, from here triangular inequalities should provide the list of potential targets,
        i.e., we know that the cost of freezone - depot is $X, hence adding any Parcel increases cost by $dX (based
        on distances and triangular inequality) but will also add $Y for transporting parcel. This values can be
        ordered in a descending manner.

        At iteration k, the truck has already a last item (the one before the Depot) and from here we repeat the same
        exercise with whatever remains in the list of available parcels.
        """
        values = {}
        profit = 0
        lastidx = self.Tour[len(self.Tour)-2] # This is the last node just before going to the Truck Depot

        for key, parcel in unassigned.List.items():
            # The addition of the parcel should pay for the cost of delivering it
            profit = parcel.Price - ((distances[(lastidx, parcel.GlobalId)]+distances[(parcel.GlobalId, self.GlobalId)]) - distances[(lastidx,self.GlobalId)])*self.TransportCost
            values[int(key)]= profit

        self.Preferences = values

        return values

    def __str__(self):
        return 'Truck id: ' + str(self.id) + ' Global id: ' + str(self.GlobalId)


class Trucks(object):
    def __init__(self):
        self.idx = 0
        self.List = {}

    def AddTruck(self, truck):
        self.List[truck.GlobalId] = truck


class Parcel(Items):
    _counter = 0
    def __init__(self, price, weight, lat, lon):
        self.id = Parcel._counter
        self.DbID = 0
        self.GlobalId = Items._globalCounter
        Items._globalCounter += 1
        self.Price = price # Total price that parcel will pay for delivery at its location
        self.Weight = weight
        self.Location = (lat, lon)
        Parcel._counter += 1
        self.Assigned = False # Boolean that indicates if a Parcel is being assigned to a truck or not
        self.UnloadingTime = 10 # This needs to be read from the database or somewhere!!!
        self.TimeMin = 0 # Lower bound time window in minutes, not used yet
        self.TimeMax = 0 # Upper bound time window in minutes, not used yet
        self.LoadType = 0 # Hardcoded now, needs to be read from the database
        # Assuming that a parcel belongs to only one type
        # TODO: Add type of load for compatibility purposes

    def __str__(self):
        return 'Parcel id: '+ str(self.id) + ' Global id: ' + str(self.GlobalId)


class Parcels(object):
    def __init__(self):
        self.idx = 0
        self.List = {}

    def AddParcel(self, parcel):
        self.List[parcel.GlobalId] = parcel


class Warehouse(Items):
    _counter = 0
    def __init__(self, lat, lon):
        self.id = Warehouse._counter
        self.Location = (lat, lon)
        self.GlobalId = Items._globalCounter
        Items._globalCounter += 1
        Warehouse._counter += 1

    def __str__(self):
        return 'Warehouse ' + str(self.id) + ' Global id: ' +  str(self.GlobalId)


def calculate_profits(notassigned, notfulltrucks, distances):
    for keytruck, valuetruck in notfulltrucks.List.items():
        valuetruck.CalculateBest(notassigned, distances)


def assign_parcels(notassigned, notfulltrucks, timewindows, compatibility):
    """
    This function should do two things. First thing to do is to assign parcels to trucks. For that we need:
    * Check feasibility
      - Time window
      - Load type
      - Weight of the parcel and available capacity of the truck
      - etc.
    Second thing to do is to remove Parcels from NotAssignedParcels which is a dictionary (delete with del[key])
    The criteria to assign a parcel to a truck consists of:
    * There is compatibility between the parcel and the truck
    * The parcel is assigned to the truck it benefits the most, i.e., the one for which it produces the biggest profit
    The way to achieve both things in one run is to run an assignation model, quite standard and quick to run.
    Hence the Heuristic is Hybrid!!!
    """
    prob = LpProblem("The Assignment Problem", LpMaximize)
    Trucks = notfulltrucks.List
    Parcels = notassigned.List
    Trucks_Nodes = list(Trucks.keys())
    Parcels_Nodes = list(Parcels.keys())
    Indexes = list(it.product(Trucks_Nodes, Parcels_Nodes)) # This are all the possible combinations of trucks and parcels

    Routing_vars = LpVariable.dicts("X", ((i, j) for i, j in Indexes), cat='Binary') # X_{i,j} = 1 if Truck i carries Parcel j, 0 otherwise
    # The objective function is added to 'prob' first
    prob += lpSum([Trucks[i].Preferences[j]*Routing_vars[i, j] for i,j in Indexes]), "Total Assignation Profit" #
    # The constraints are added to 'prob'
    for i in Trucks_Nodes:
        prob += lpSum([Routing_vars[i, j] for j in Parcels_Nodes]) <= 1, "At most one Parcel is assigned to Truck " + str(i)

    for j in Parcels_Nodes:
        prob += lpSum([Routing_vars[i, j] for i in Trucks_Nodes]) <= 1, "At most one Truck carries Parcel " + str(j)

    if timewindows:
        for i in Trucks_Nodes:
            for j in Parcels_Nodes:
                prob += (Trucks[i].CurrentTime + times[(i,j)] - Parcels[j].TimeMin) * Routing_vars[i, j] >= 0 , "We arrive after the minimum time window for parcel " + str(j) + " using truck " + str(i)

        for i in Trucks_Nodes:
            for j in Parcels_Nodes:
                prob += (Parcels[j].TimeMax - (Trucks[i].CurrentTime + times[(i, j)])) * Routing_vars[i, j] >= 0, "We arrive before the maximum time window for parcel " + str(j) + " using truck " + str(i)

    if compatibility:
        for i in Trucks_Nodes:
            for j in Parcels_Nodes:
                if Parcels[j].LoadType not in Trucks[i].TranspCompat:
                    prob += Routing_vars[i, j] == 0, "We cannot allow transporting goods in an incompatible Truck (" + str(i) + ", " + str(j) + ")"


    # We respect the truck capacity
    for i in Trucks_Nodes:
        prob += lpSum([Routing_vars[i, j]*Parcels[j].Weight for j in Parcels_Nodes]) <= Trucks[i].UnusedCapacity , "We don't assign if available capacity exceeds available " + str(i)

    # The problem is solved using PuLP's choice of Solver
    prob.solve(pulp.GLPK(options=['--mipgap', '0.05'], msg=0))

    # Postprocessing to eliminate parcels from NotAssignedParcels
    # Postprocessing to add the Parcels to the Tour variable of the Trucks
    numVarOnes = 0
    for i in Trucks_Nodes:
        for j in Parcels_Nodes:
            if Routing_vars[i, j].value() == 1:
                numVarOnes = True
                AllTrucks.List[i].Tour.insert(len(AllTrucks.List[i].Tour)-1,j)
                AllTrucks.List[i].UnusedCapacity -= NotAssignedParcels.List[j].Weight # Every time a parcel is assigned, we remove the corresponding weight
                AllTrucks.List[i].CarriedValue += NotAssignedParcels.List[j].Price
                AllTrucks.List[i].CurrentTime += times[(len(AllTrucks.List[i].Tour)-2),len(AllTrucks.List[i].Tour)-1] + NotAssignedParcels.List[j].UnloadingTime
                NotAssignedParcels.RemoveParcel(j)
                if AllTrucks.List[i].UnusedCapacity <= AllTrucks.List[i].Capacity*0.05: # Tolerance = 5%, makes sense as the Truck will be filled up to 95% capacity!
                    NotFullTrucks.RemoveTruck(i)

    return numVarOnes


def calculate_value(Truck):
    income = Truck.CarriedValue
    cost = 0
    for i in range(1,len(Truck.Tour)-1,1):
        cost += distances[Truck.Tour[i-1],Truck.Tour[i]]*Truck.TransportCost
    return (income-cost)


def process_truck(dict, truckscol, parcelscol, notfulltrucks, distances, times):
    # Order of compatibilities
    # 1. General
    # 2. Perishable
    # 3. Dangerous
    # 4. Valuable
    # 5. Live Animal
    TmpTruck = Truck(dict['truckType_cost'], dict['Maximum_load'], dict['Garage_Latitude'], dict['Garage_Longitude'])
    TmpTruck.DbID = dict['id']
    # Compatibility for Transportation
    TmpTruck.TranspCompat.append(int(dict['Load_type_General']) * 1) # 1. General
    TmpTruck.TranspCompat.append(int(dict['load_type_Perishable']) * 2) # 2. Perishable
    TmpTruck.TranspCompat.append(int(dict['Load_type_Dangerous']) * 3) # 3. Dangerous
    TmpTruck.TranspCompat.append(int(dict['Load_type_Valuable']) * 4) # 4. Valuable
    TmpTruck.TranspCompat.append(int(dict['Load_type_Live_Animal']) * 5) # 5. Live Animal

    for keyparcel, valueparcel in parcelscol.List.items():
        Lat1, Lon1 = TmpTruck.Depot
        Lat2, Lon2 = valueparcel.Location
        stri = 'http://110.164.130.191:7001/osrm/route/v1/driving/' + str(Lon1) + ',' + str(Lat1) + ';' + str(Lon2) + ',' + str(Lat2)  + '?exclude=motorway'
        r = requests.get(stri)
        t = r.json()
        distancetmp = t['routes'][0]['legs'][0]['distance']
        timetmp = t['routes'][0]['legs'][0]['duration']
        distances[(TmpTruck.GlobalId, valueparcel.GlobalId)] = distancetmp
        distances[(valueparcel.GlobalId, TmpTruck.GlobalId)] = distancetmp
        times[(TmpTruck.GlobalId, valueparcel.GlobalId)] = timetmp
        times[(valueparcel.GlobalId, TmpTruck.GlobalId)] = timetmp

    for keyparcel, valuetruck in truckscol.List.items():
        Lat1, Lon1 = TmpTruck.Depot
        Lat2, Lon2 = valuetruck.Depot
        stri = 'http://110.164.130.191:7001/osrm/route/v1/driving/' + str(Lon1) + ',' + str(Lat1) + ';' + str(Lon2) + ',' + str(Lat2) + '?exclude=motorway'
        r = requests.get(stri)
        t = r.json()
        distancetmp = t['routes'][0]['legs'][0]['distance']
        timetmp = t['routes'][0]['legs'][0]['duration']
        distances[(TmpTruck.GlobalId, valuetruck.GlobalId)] = distancetmp
        times[(TmpTruck.GlobalId, valuetruck.GlobalId)] = timetmp
        distances[(valuetruck.GlobalId, TmpTruck.GlobalId)] = distancetmp
        times[(valuetruck.GlobalId, TmpTruck.GlobalId)] = timetmp

    distances[(TmpTruck.GlobalId, TmpTruck.GlobalId)] = 0.0
    times[(TmpTruck.GlobalId, TmpTruck.GlobalId)] = 0.0

    truckscol.AddTruck(TmpTruck) # We add it just at the end, as before it just makes one stupid call that is not needed distance(x,x)


def process_parcel(dict, truckscol, parcelscol, notassigned, distances, times):
    TmpParcel = Parcel(dict['shippingRate'], dict['weight'], dict['shippingAddressLatitude'], dict['shippingAddressLongitude'])
    TmpParcel.DbID = dict['id']
    TmpParcel.UnloadingTime = dict['downloadTime']
    TmpParcel.LoadType = dict['productType']

    for keyparcel, valueparcel in parcelscol.List.items():
        Lat1, Lon1 = TmpParcel.Location
        Lat2, Lon2 = valueparcel.Location
        stri = 'http://110.164.130.191:7001/osrm/route/v1/driving/' + str(Lon1) + ',' + str(Lat1) + ';' + str(Lon2) + ',' + str(Lat2)  + '?exclude=motorway'
        r = requests.get(stri)
        t = r.json()
        distancetmp = t['routes'][0]['legs'][0]['distance']
        timetmp = t['routes'][0]['legs'][0]['duration']
        distances[(TmpParcel.GlobalId, valueparcel.GlobalId)] = distancetmp
        distances[(valueparcel.GlobalId, TmpParcel.GlobalId)] = distancetmp
        times[(TmpParcel.GlobalId, valueparcel.GlobalId)] = timetmp
        times[(valueparcel.GlobalId, TmpParcel.GlobalId)] = timetmp

    for keyparcel, valuetruck in truckscol.List.items():
        Lat1, Lon1 = TmpParcel.Location
        Lat2, Lon2 = valuetruck.Depot
        stri = 'http://110.164.130.191:7001/osrm/route/v1/driving/' + str(Lon1) + ',' + str(Lat1) + ';' + str(Lon2) + ',' + str(Lat2) + '?exclude=motorway'
        r = requests.get(stri)
        t = r.json()
        distancetmp = t['routes'][0]['legs'][0]['distance']
        timetmp = t['routes'][0]['legs'][0]['duration']
        distances[(TmpParcel.GlobalId, valuetruck.GlobalId)] = distancetmp
        times[(TmpParcel.GlobalId, valuetruck.GlobalId)] = timetmp
        distances[(valuetruck.GlobalId, TmpParcel.GlobalId)] = distancetmp
        times[(valuetruck.GlobalId, TmpParcel.GlobalId)] = timetmp

    distances[(TmpParcel.GlobalId, TmpParcel.GlobalId)] = 0.0
    times[(TmpParcel.GlobalId, TmpParcel.GlobalId)] = 0.0

    parcelscol.AddParcel(TmpParcel)


def process_optimisation(alltrucks, allparcels, distances, times, freezone, notassigned, notfulltrucks, timewindows, compatibility):
    for keytruck, valuetruck in alltrucks.List.items():
        valuetruck.Tour.append(freezone.GlobalId)
        valuetruck.Tour.append(valuetruck.GlobalId)
        notfulltrucks.AddTruck(keytruck, valuetruck)

    for keyparcel, valueparcel in AllParcels.List.items():
        notassigned.AddParcel(keyparcel,valueparcel)

    # Calculate distances from Warehouse to everything else
    distances[(freezone.GlobalId, freezone.GlobalId)] = 0.0
    times[(freezone.GlobalId, freezone.GlobalId)] = 0.0

    for keyparcel, valueparcel in allparcels.List.items():
        Lat1, Lon1 = freezone.Location
        Lat2, Lon2 = valueparcel.Location
        stri = 'http://110.164.130.191:7001/osrm/route/v1/driving/' + str(Lon1) + ',' + str(Lat1) + ';' + str(Lon2) + ',' + str(Lat2)  + '?exclude=motorway'
        r = requests.get(stri)
        t = r.json()
        distancetmp = t['routes'][0]['legs'][0]['distance']
        timetmp = t['routes'][0]['legs'][0]['duration']
        distances[(freezone.GlobalId, valueparcel.GlobalId)] = distancetmp
        distances[(valueparcel.GlobalId, freezone.GlobalId)] = distancetmp
        times[(freezone.GlobalId, valueparcel.GlobalId)] = timetmp
        times[(valueparcel.GlobalId, freezone.GlobalId)] = timetmp

    for keyparcel, valuetruck in alltrucks.List.items():
        Lat1, Lon1 = freezone.Location
        Lat2, Lon2 = valuetruck.Depot
        stri = 'http://110.164.130.191:7001/osrm/route/v1/driving/' + str(Lon1) + ',' + str(Lat1) + ';' + str(Lon2) + ',' + str(Lat2) + '?exclude=motorway'
        r = requests.get(stri)
        t = r.json()
        distancetmp = t['routes'][0]['legs'][0]['distance']
        timetmp = t['routes'][0]['legs'][0]['duration']
        distances[(freezone.GlobalId, valuetruck.GlobalId)] = distancetmp
        times[(freezone.GlobalId, valuetruck.GlobalId)] = timetmp
        distances[(valuetruck.GlobalId, freezone.GlobalId)] = distancetmp
        times[(valuetruck.GlobalId, freezone.GlobalId)] = timetmp

    # The Greedy Loop!
    iterating = True
    counter = 0
    while iterating:
        calculate_profits(notassigned, notfulltrucks, distances)  # This will order the list of unassigned
        iterating = bool(assign_parcels(notassigned, notfulltrucks, timewindows, compatibility))  # This will assign an reduce the unassigned list, also assigns Truth value to iterating
        counter += 1


def post_process(alltrucks, allparcels, notassigned, notfulltrucks, distances, times):
    # TODO: Transfer the routes to the database and change the packages status
    # TODO: send array of tuples with longitude and Latitude, profit , distance and duration
    for keytruck, valuetruck in alltrucks.List.items():
        TourDBId = []
        TmpTour = valuetruck.Tour
        TourDBId.append(TmpTour[0])
        for i in range(1, len(TmpTour) - 1, 1):
            TourDBId.append(allparcels.List[TmpTour[i]].DbID)
        TourDBId.append(valuetruck.DbID)
        valuetruck.Tour = TourDBId




        addRoute(TourDBId)



    #
    #
    #
    #

    # Global variables are cleared, the only exception is freezone that remains there
    alltrucks.List.clear()
    allparcels.List.clear()
    notassigned.List.clear()
    notfulltrucks.List.clear()
    distances.clear()
    times.clear()
    Items._globalCounter = 1 # There is already one object in the system (Warehouse)



def main_run():
    # On this one we should have a couple of lists for each thing, selector based on time (like odd an even hour of the day)
    global AllTrucks, AllParcels, NotAssignedParcels, NotFullTrucks,distances, times, FreeZone

    AllTrucks = Trucks() # List needs to be cleared after the optimisation is performed with AllTrucks.List.clear()
    AllParcels = Parcels() # List needs to be cleared after the optimisation is performed with AllParcels.List.clear()
    NotAssignedParcels = UnassignedParcels() # List needs to be cleared after the optimisation is performed with NotAssignedParcels.List.clear()
    NotFullTrucks = UnFullTrucks() # List needs to be cleared after the optimisation is performed with NotFullTrucks.List.clear()
    distances = {} # dictionary will need to be cleared after the optimisation is performed with distances.clear()
    times = {} # dictionary will need to be cleared after the optimisation is performed with times.clear()
    FreeZone = Warehouse(13.66087464742539,100.74363112449647) # We initialize the warehouse here and leave it as this forever!
    # End of global variables that should be visible throughout

    # connection to define how to receive and process incoming messages
    connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()

    channel.queue_declare(queue='Backhaul1')

    def process(body):
        message = pickle.loads(body)
        # Here we need to update the lists based on what we receive
        if message['typeMessage'] == 'truck':
            process_truck(message, AllTrucks, AllParcels, NotFullTrucks, distances, times)
        elif message['typeMessage'] == 'parcel':
            process_parcel(message, AllTrucks, AllParcels, NotAssignedParcels, distances, times)
        elif message['typeMessage'] == 'optimisation':
            process_optimisation(AllTrucks, AllParcels, distances, times, FreeZone, NotAssignedParcels, NotFullTrucks, False, True)# Time windows should stay at False at the moment
            # Call here function to postprocess solution
            post_process(AllTrucks,AllParcels, NotAssignedParcels, NotFullTrucks, distances, times)

    def callback(ch, method, properties, body):
        process(body)

    channel.basic_consume(callback,
                          queue='Backhaul1',
                          no_ack=True)

    channel.start_consuming()

if __name__ == '__main__':
    main_run()
