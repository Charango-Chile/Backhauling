from django.urls import path
from smart.views import TruckList, CreateTruck, UpdateTruck, TruckDetail, TruckDelete
from smart.views import DriverList, CreateDriver, UpdateDriver, DriverDetail, DriverDelete
from smart.views import PackageList, CreatePackage, UpdatePackage, PackageDetail, PackageDelete, Welcome
from smart.views import DashboardCarrier, DashboardShipper, DashboardAdmin, TruckDeal, DeliveryDeal, RouteDetail,ParcelDetail

from django.contrib.auth.decorators import login_required
from smart.views import LogoutSmart
from smart.views import change_truck_status, accept_proposal_deal, end_deal, run_process

urlpatterns = [

    path('logout/', login_required(LogoutSmart.as_view()), name='logout'),
    path('welcome/', login_required(Welcome.as_view()), name='welcome'),

    path('trucks/', login_required(TruckList.as_view()), name='truck_list'),
    path('create_truck/', login_required(CreateTruck.as_view()), name='create_truck'),
    path('update_truck/<int:pk>/', login_required(UpdateTruck.as_view()), name='update_truck'),
    path('truck_detail/<int:pk>/', login_required(TruckDetail.as_view()), name='truck_detail'),
    path('truck_delete/<int:pk>/', login_required(TruckDelete.as_view()), name='truck_delete'),
    path('dashboard_carrier/', login_required(DashboardCarrier.as_view()), name='dashboard_carrier'),
    path('dashboard_shipper/', login_required(DashboardShipper.as_view()), name='dashboard_shipper'),
    path('dashboard_admin/', login_required(DashboardAdmin.as_view()), name='dashboard_admin'),

    path('truck_deal/', login_required(TruckDeal.as_view()), name='truck_deal'),
    path('delivery_deal/', login_required(DeliveryDeal.as_view()), name='delivery_deal'),

    path('drivers/', login_required(DriverList.as_view()), name='driver_list'),
    path('create_driver/', login_required(CreateDriver.as_view()), name='create_driver'),
    path('update_driver/<int:pk>/', login_required(UpdateDriver.as_view()), name='update_driver'),
    path('driver_detail/<int:pk>/', login_required(DriverDetail.as_view()), name='driver_detail'),
    path('driver_delete/<int:pk>/', login_required(DriverDelete.as_view()), name='driver_delete'),

    path('packages/', login_required(PackageList.as_view()), name='package_list'),
    path('create_package/', login_required(CreatePackage.as_view()), name='create_package'),
    path('update_package/<int:pk>/', login_required(UpdatePackage.as_view()), name='update_package'),
    path('package_detail/<int:pk>/', login_required(PackageDetail.as_view()), name='package_detail'),
    path('package_delete/<int:pk>/', login_required(PackageDelete.as_view()), name='package_delete'),

    path('wks/truck/', change_truck_status, name='change_truck_status'),
    path('wks/accepted/', accept_proposal_deal, name='accept_proposal_deal'),
    path('wks/end/', end_deal, name='end_deal'),
    path('run_process/', run_process, name='run_process'),
    path('route_detail/<int:pk>/', login_required(RouteDetail.as_view()), name='route_detail'),
    path('parcel_detail/<int:pk>/', login_required(ParcelDetail.as_view()), name='parcel_detail'),

]