from django.db import models
from django.utils import timezone


# Create your models here.

class ShippingPrice(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE, help_text="Enter a valid creation user.")
    id_ShippingPrice = models.CharField(max_length=3, help_text="Enter a short Description of Route status")
    description = models.CharField(max_length=30, help_text="Enter a  Description")
    weight = models.FloatField(default=0, help_text="Enter package's less than Weight ")
    price = models.FloatField(default=0, help_text="Enter package's Price")
    created_Date = models.DateTimeField(default=timezone.now, help_text="Enter a Date Creation of Object")

    def __str__(self):
        return self.description

class RouteStatus(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE, help_text="Enter a valid creation user.", default=1)
    id_Status = models.CharField(max_length=3, help_text="Enter a short Description of Route status")
    description = models.CharField(max_length=30, help_text="Enter a  Description")
    created_Date = models.DateTimeField(default=timezone.now, help_text="Enter a Date Creation of Object")

    def __str__(self):
        return self.description

class State(models.Model):
    key = models.CharField(max_length=20, help_text="Enter Key")
    value = models.CharField(max_length=100, help_text="Enter Value")

    def __str__(self):
        return self.key



class SmartPerms(models.Model):
    idUser = models.CharField(max_length=3, help_text="Enter a short Description of Product Type ")

    class Meta:
        permissions = (
        ("carrier", "User is a Carrier"), ("admin", "user is a Admin"), ("shipper", "user is a Shipper"),)

    def __str__(self):
        return self.idUser


class TruckType(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE, help_text="Enter a valid creation user.")
    description_Type = models.CharField(max_length=200, help_text="Enter a  Description of Truck Type")
    maximun_Weight = models.FloatField(default=0, help_text="Enter Truck's Maximun Weight (Ton)")
    cost = models.FloatField(default=0, help_text="Enter Truck's Cost (Baht/kilometer) ")
    created_Date = models.DateTimeField(default=timezone.now, help_text="Enter a Date Creation of Object")

    def __str__(self):
        return self.description_Type


class ProductType(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE, help_text="Enter a valid creation user.")
    id_Product = models.CharField(max_length=3, help_text="Enter a short Description of Product Type")
    description_Type = models.CharField(max_length=200, help_text="Enter a  Description of Product Type")
    created_Date = models.DateTimeField(default=timezone.now, help_text="Enter a Date Creation of Object")

    def __str__(self):
        return self.description_Type


class PackageStatus(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE, help_text="Enter a valid creation user.")
    id_Status = models.CharField(max_length=3, help_text="Enter a short Description of packahe status")
    description = models.CharField(max_length=30, help_text="Enter a  Description")
    created_Date = models.DateTimeField(default=timezone.now, help_text="Enter a Date Creation of Object")

    def __str__(self):
        return self.description


class Truck(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE, help_text="Enter a valid creation user.")
    Id_Truck = models.CharField(max_length=6, help_text="Enter a truck id.")
    Plate = models.CharField(max_length=10, help_text="Enter a truck's plate")
    Brand = models.CharField(default='', max_length=30, help_text="Enter a truck's Brand")
    Model = models.CharField(default='', max_length=30, help_text="Enter a truck's Model")
    Color = models.CharField(default='', max_length=30, help_text="Enter a truck's Color")
    Year_Of_Production = models.IntegerField(default=1900, help_text="Enter a truck's Year Of Production")
    Maximum_load = models.IntegerField(default=0, help_text="Enter Truck's Maximun Load ")
    Maximum_volume = models.IntegerField(default=0, help_text="Enter Truck's Maximun Volumen ")
    truckType = models.ForeignKey(TruckType, on_delete=models.CASCADE, null=True)
    status = models.BooleanField(default=False, help_text="Choose Truck's Status")
    proposed = models.BooleanField(default=False, help_text="Choose Truck's Status")
    acepted = models.BooleanField(default=False, help_text="Choose Truck's Status")
    Is_Open_Truck = models.BooleanField(default=False, help_text="True, if the Truck is Open")
    Has_Cabinet = models.BooleanField(default=False, help_text="True, if the Truck has cabinet")
    Is_Refrigerated_Cabinet = models.BooleanField(default=False, help_text="True, if the Truck's Cabinet is refrigarated")
    Is_Armored_Cabinet = models.BooleanField(default=False, help_text="True, if the Truck's Cabinet is  armored")
    Garage_Latitude = models.FloatField(help_text="Enter Truck's Gagage Latitud Point or click map bellow")
    Garage_Longitude = models.FloatField(help_text="Enter Truck's Garage Longitud Point or click map bellow")
    Load_type_General = models.BooleanField(default=False, help_text="True, if the Truck can transport that items")
    Load_type_Perishable = models.BooleanField(default=False, help_text="True, if the Truck can transport that items")
    Load_type_Dangerous = models.BooleanField(default=False, help_text="True, if the Truck can transport that items")
    Load_type_Valuable = models.BooleanField(default=False, help_text="True, if the Truck can transport that items")
    Load_type_Live_Animal = models.BooleanField(default=False, help_text="True, if the Truck can transport that items")
    observations = models.TextField(help_text="Enter a Observations of the truck", max_length=200, blank=True)
    created_Date = models.DateTimeField(default=timezone.now, help_text="Enter a Date Creation of Object")
    is_Deleted = models.BooleanField(default=False)

    def __str__(self, **kwargss):
        return self.Plate


class Route(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE, help_text="Enter a valid creation user.", blank=True,
                             null=True)
    status = models.ForeignKey(RouteStatus, on_delete=models.CASCADE)
    truck = models.ForeignKey(Truck, on_delete=models.CASCADE)
    route = models.TextField(help_text="Enter a Route ", max_length=2000, blank=True)
    cords = models.TextField(help_text="Enter cords ", max_length=6000, blank=True)
    profit = models.FloatField(help_text="Enter profit", blank=True, null=True)
    distance = models.FloatField(help_text="Enter  distance", blank=True, null=True)
    duration = models.FloatField(help_text="Enter duration", blank=True, null=True)
    created_Date = models.DateTimeField(default=timezone.now, help_text="Enter a Date Creation of Object")
    start_Date = models.DateTimeField(help_text="Enter a Date Creation of Object", blank=True, null=True)

    def __str__(self):
        return self.idRoute


class Driver(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE, help_text="Enter a valid creation user.")
    id_Driver = models.CharField(max_length=5, help_text="Enter a id Driver.")
    first_Name = models.CharField(max_length=50, help_text="Enter a driver's first name")
    last_Name = models.CharField(max_length=50, help_text="Enter a driver's last name")
    address = models.CharField(max_length=200, help_text="Enter a driver's address")
    telephone = models.CharField(max_length=20, help_text="Enter a driver's telephone")
    email = models.EmailField(max_length=50, help_text="Enter a driver's e-mail")
    next_Of_Kin_Name = models.CharField(max_length=50, help_text="Enter a driver's next Of Kin Name")
    next_Of_Kin_Phone = models.CharField(max_length=50, help_text="Enter a driver's next Of Kin Phone")
    licence_Number = models.CharField(max_length=20, help_text="Enter a driver's licence Number")
    Expiration_Licence_Date = models.DateField(default=timezone.now,
                                               help_text="Enter a driver's Expiration Date of Licence")
    load_type_General = models.BooleanField(default=False, help_text="True, if the Driver can transport that items")
    load_type_Perishable = models.BooleanField(default=False, help_text="True, if the Driver can transport that items")
    load_type_Dangerous = models.BooleanField(default=False, help_text="True, if the Driver can transport that items")
    load_type_Valuable = models.BooleanField(default=False, help_text="True, if the Driver can transport that items")
    load_type_Live_Animal = models.BooleanField(default=False, help_text="True, if the Driver can transport that items")
    observations = models.TextField(help_text="Enter a Observations of the Driver", max_length=200, blank=True)
    status = models.BooleanField(default=False, help_text="Choose Driver's Status")
    created_Date = models.DateTimeField(default=timezone.now, help_text="Enter a Date Creation of Object")
    is_Deleted = models.BooleanField(default=False)

    def __str__(self):
        return self.id_Driver


class Package(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE, help_text="Enter a valid creation user.")
    id_Package = models.CharField(max_length=100, help_text="Enter a id Package.")
    description = models.CharField(max_length=50, help_text="Enter a Package's description ")
    shipping_Address = models.CharField(max_length=150, help_text="Enter a Package's Shipping Address or click map bellow")
    shipping_Address_Latitude = models.FloatField(default=0, help_text="Enter Truck's shipping Address Latitude Point or click map bellow")
    shipping_Address_Longitude = models.FloatField(default=0,
                                                   help_text="Enter Truck's shipping Address Longitude Point")
    weight = models.IntegerField(default=0, help_text="Enter a Package's weight")
    volume = models.IntegerField(default=0, help_text="Enter a Package's volume ")
    receiver = models.CharField(max_length=100, help_text="Enter a Package's Receiver ")
    loading_Time = models.IntegerField(default=0, help_text="Enter a Package's loading Time")
    download_Time = models.IntegerField(default=0, help_text="Enter a Package's download Time")
    product_Type = models.ForeignKey(ProductType, help_text="Enter a Package's kind of Product",
                                     on_delete=models.CASCADE)
    shipping_Rate = models.FloatField(default=0, help_text="Enter a Package's shipping Rate")
    observations = models.TextField(help_text="Enter a Observations of the Package", max_length=200, blank=True)
    status = models.ForeignKey(PackageStatus, on_delete=models.CASCADE)
    route = models.OneToOneField(Route, on_delete=models.CASCADE, null=True)
    created_Date = models.DateTimeField(default=timezone.now, help_text="Enter a Date Creation of Object")
    is_Deleted = models.BooleanField(default=False)
    time_max = models.DateTimeField(help_text="Enter a valid Date Time Max", default=timezone.now, blank=True)
    time_min = models.DateTimeField(help_text="Enter a valid Date Time Min", default=timezone.now, blank=True)
    def __str__(self):
        return self.id_Package
