# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.views.generic.base import View
from django.views.generic.edit import UpdateView, CreateView
from django.views.generic.list import ListView
from smart.forms import TruckForm, DriverForm, PackageForm
from smart.models import Truck, Driver, Package
from django.urls import reverse_lazy
from django.views.generic.detail import DetailView
from django.http.response import HttpResponseRedirect
from django.http import HttpResponse
from django.views.generic.base import TemplateView

from django.contrib.auth.views import LoginView, LogoutView


# Login  Views
class LoginSmart(LoginView):
    template_name = 'login.html'
    next_page = 'trucks.html'


class LogoutSmart(LogoutView):
    template_name = 'logout.html'


class Index(TemplateView):
    template_name = 'index.html'


# Truck Views
class TruckList(ListView):



        model = Truck
        template_name = 'trucks.html'
        context_object_name = 'trucks'

        def get_queryset(self):
                queryset = super(TruckList, self).get_queryset()
                queryset = queryset.filter(user=self.request.user, is_Deleted=False)
                return queryset

        #def post(self, request):
       #     if not request.user.is_authenticated():
       #         return HttpResponseRedirect('login.html')

class CreateTruck(CreateView):
    form_class = TruckForm
    template_name = 'truck.html'
    success_url = reverse_lazy('truck_list')

    def post(self, request, *args, **kwargs):
        form_class = self.get_form_class()
        form = self.get_form(form_class)
        if form.is_valid():
            truck = form.save(commit=False)
            truck.user = request.user
            truck.save()




            return HttpResponseRedirect(self.success_url)


class UpdateTruck(UpdateView):
    model = Truck
    template_name = 'truck.html'
    form_class = TruckForm
    success_url = reverse_lazy('truck_list')


class TruckDetail(DetailView):
    model = Truck
    template_name = 'truck_detail.html'


class TruckDelete(DetailView):
    model = Truck
    template_name = 'truck_delete.html'
    form_class = TruckForm
    success_url = reverse_lazy('truck_list')

    def post(self, request, *args, **kwargs):
        Truck.objects.filter(id=kwargs['pk']).update(is_Deleted=True)
        return HttpResponseRedirect(self.success_url)


# Driver Views
class DriverList(ListView):
    model = Driver
    template_name = 'drivers.html'
    context_object_name = 'drivers'

    def get_queryset(self):
        queryset = super(DriverList, self).get_queryset()
        queryset = queryset.filter(user=self.request.user, is_Deleted=False)
        return queryset


class CreateDriver(CreateView):
    form_class = DriverForm
    template_name = 'driver.html'
    success_url = reverse_lazy('driver_list')

    def post(self, request, *args, **kwargs):
        form_class = self.get_form_class()
        form = self.get_form(form_class)
        if form.is_valid():
            driver = form.save(commit=False)
            driver.user = request.user
            driver.save()
            return HttpResponseRedirect(self.success_url)


class UpdateDriver(UpdateView):
    model = Driver
    template_name = 'driver.html'
    form_class = DriverForm
    success_url = reverse_lazy('driver_list')


class DriverDetail(DetailView):
    model = Driver
    template_name = 'driver_detail.html'


class DriverDelete(UpdateView):
    model = Driver
    template_name = 'driver_delete.html'
    form_class = DriverForm
    success_url = reverse_lazy('driver_list')

    def post(self, request, *args, **kwargs):
        Driver.objects.filter(id=kwargs['pk']).update(is_Deleted=True)
        return HttpResponseRedirect(self.success_url)


# Packages Views
class PackageList(ListView):
    model = Package
    template_name = 'packages.html'
    context_object_name = 'packages'

    def get_queryset(self):
        queryset = super(PackageList, self).get_queryset()
        queryset = queryset.filter(user=self.request.user, is_Deleted=False)
        return queryset


class CreatePackage(CreateView):
    form_class = PackageForm
    template_name = 'package.html'
    success_url = reverse_lazy('package_list')

    def post(self, request, *args, **kwargs):
        form_class = self.get_form_class()
        form = self.get_form(form_class)
        if form.is_valid():
            package = form.save(commit=False)
            package.user = request.user
            package.save()
            return HttpResponseRedirect(self.success_url)


class UpdatePackage(UpdateView):
    model = Package
    template_name = 'package.html'
    form_class = PackageForm
    success_url = reverse_lazy('package_list')


class PackageDetail(DetailView):
    model = Package
    template_name = 'package_detail.html'


class PackageDelete(UpdateView):
    model = Package
    template_name = 'package_delete.html'
    form_class = PackageForm
    success_url = reverse_lazy('package_list')

    def post(self, request, *args, **kwargs):
        Package.objects.filter(id=kwargs['pk']).update(is_Deleted=True)
        return HttpResponseRedirect(self.success_url)

