from django import forms
from smart.models import Truck, Driver, Package


class TruckForm(forms.ModelForm):
    class Meta:
        model = Truck

        fields = ('Plate', 'truck_Type', 'driver_Name',
                  'special_Condition_Note', 'current_Location',
                  'status')
        def __init__(self, *args, **kwargs):
           super(TruckForm, self).__init__(*args, **kwargs)
           for field in iter(self.fields):
                if field != 'activate':
                    self.fields[field].widget.attrs.update({
               'class': 'form-control'
                    })





class DriverForm(forms.ModelForm):
    class Meta:
        model = Driver
        fields = ('id_Driver', 'first_Name', 'last_Name', 'address', 'telephone', 'email', 'next_Of_Kin_Name','next_Of_Kin_Phone',
                  'licence_Number', 'Expiration_Licence_Date', 'load_type_General', 'load_type_Perishable'
                  , 'load_type_Dangerous','load_type_Valuable','load_type_Live_Animal','load_type_General','observations',
                   'status',
                  )
        def __init__(self, *args, **kwargs):
           super(DriverForm, self).__init__(*args, **kwargs)
           for field in iter(self.fields):
                if field != 'activate':
                    self.fields[field].widget.attrs.update({
               'class': 'form-control'
                    })

class PackageForm(forms.ModelForm):
    class Meta:
        model = Package
        fields = ( 'product_Type', 'product_Name', 'special_Product_Requirement', 'weight',
                  'receiver_name','contact_no', 'receiver_company', 'email', 'shipping_Address_No',
                  'shipping_Address_Street', 'shipping_Address_Subprovince','shipping_Address_Province',
                  'shipping_Address_Postal_Code','status',)
        def __init__(self, *args, **kwargs):
           super(PackageForm, self).__init__(*args, **kwargs)
           for field in iter(self.fields):
                if field != 'activate':
                    self.fields[field].widget.attrs.update({
               'class': 'form-control'
                    })




