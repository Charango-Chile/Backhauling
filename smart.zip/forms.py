from django import forms
from smart.models import Truck, Driver, Package


class TruckForm(forms.ModelForm):
    class Meta:
        model = Truck

        fields = ('Id_Truck', 'Plate', 'Brand', 'Model', 'Color', 'Year_Of_Production', 'truckType', 'Maximun_load','Maximun_load',
                  'Is_Open_Truck', 'Has_Cabinet', 'Is_Refrigerated_Cabinet'
                  , 'Is_Armored_Cabinet','Garage_Latitude','Garage_Longitude','Load_type_General','Load_type_General',
                  'Load_type_Dangerous','Load_type_Valuable','Load_type_Live_Animal', 'observations', 'status',
                  )
        def __init__(self, *args, **kwargs):
           super(TruckForm, self).__init__(*args, **kwargs)
           for field in iter(self.fields):
                if field != 'activate':
                    self.fields[field].widget.attrs.update({
               'class': 'form-control'
                    })


class DriverForm(forms.ModelForm):
    class Meta:
        model = Driver
        fields = ('id_Driver', 'first_Name', 'last_Name', 'address', 'telephone', 'email', 'next_Of_Kin_Name','next_Of_Kin_Phone',
                  'licence_Number', 'Expiration_Licence_Date', 'load_type_General', 'load_type_Perishable'
                  , 'load_type_Dangerous','load_type_Valuable','load_type_Live_Animal','load_type_General','observations',
                   'status',
                  )
        def __init__(self, *args, **kwargs):
           super(DriverForm, self).__init__(*args, **kwargs)
           for field in iter(self.fields):
                if field != 'activate':
                    self.fields[field].widget.attrs.update({
               'class': 'form-control'
                    })

class PackageForm(forms.ModelForm):
    class Meta:
        model = Package
        fields = ('id_Package', 'description', 'shipping_Address', 'shipping_Address_Latitude', 'shipping_Address_Longitude', 'weight',
                  'volume','receiver', 'loading_Time', 'download_Time', 'product_Type', 'shipping_Rate', 'status',
                  )
        def __init__(self, *args, **kwargs):
           super(PackageForm, self).__init__(*args, **kwargs)
           for field in iter(self.fields):
                if field != 'activate':
                    self.fields[field].widget.attrs.update({
               'class': 'form-control'
                    })


