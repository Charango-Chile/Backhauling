import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "bhsite.settings")
import django
django.setup()

from smart.models import RouteStatus, Truck, Package, Route
from django.utils import timezone


# TODO: send array of tuples with longitude and Latitude, profit , distance and duration

def addRoute(parcelsTour, coordsTour, tourDuration, tourDistance ):
    truck = Truck.objects.filter(id=parcelsTour[len(parcelsTour)-1])
    truck.update(status=False)
    status = RouteStatus.objects.filter(id=1)
    route = Route()
    route.user = truck.user
    route.status = status
    cord_str = ""
    for x in range(1, len(coordsTour) - 1):
        cord_str = cord_str + str(coordsTour[x]) + ";"
    route.cords = cord_str
    route.duration = tourDuration
    #TODO add this fields
    #route.cost
    #route.income
    # route.payment
    route.distance = tourDistance
    route.truck = parcelsTour[len(parcelsTour)-1]
    route_str = ""
    for x in range(1, len(parcelsTour) - 1):
        route_str = route_str + str(parcelsTour[x]) + ";"
    route.route = route_str
    route.created_Date = timezone.now()
    route.save()
    #update packageslist
    for x in range(1, len(parcelsTour) - 1):
        updateParcelStatus(parcelsTour[x],route.id)


def updateTruckStatus(idtruck):
    truck = Truck.objects.filter(id=idtruck)
    # TODO: change truck proposal status
    truck.update(status=False)

def updateParcelStatus(idPackage,idRoute):
    routeObj = Route.objects.filter(id=idRoute)
    package = Package.objects.filter(id=idPackage)
    package.update(route=routeObj,status=2)
