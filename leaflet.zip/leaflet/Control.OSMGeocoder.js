/*global L */

L.Control.OSMGeocoder = L.Control.extend({
	options: {
		collapsed: true,
		position: 'topright',
		text: 'Locate',
        email: null,
        bounds: null,
		callback: function (results) {
			var bbox = results[0].boundingbox,
				first = new L.LatLng(bbox[0], bbox[2]),
				second = new L.LatLng(bbox[1], bbox[3]),
				bounds = new L.LatLngBounds([first, second]);
			this._map.fitBounds(bounds);
		}
	},

	initialize: function (options) {
		L.Util.setOptions(this, options);
	},

	onAdd: function (map) {
		this._map = map;
        
		this._container = L.DomUtil.create('div', L.Control.OSMGeocoder.CLASS_NAME);
        this._form = L.DomUtil.create('form', L.Control.OSMGeocoder.CLASS_NAME + '-form');

        this._input = L.DomUtil.create('input', L.Control.OSMGeocoder.CLASS_NAME + '-input', this._form);
		this._input.type = "text";
        
        this._submit = L.DomUtil.create('button', L.Control.OSMGeocoder.CLASS_NAME + '-submit', this._form);
		this._submit.type = "submit";
		this._submit.innerHTML = this.options.text;

        L.DomEvent.disableClickPropagation(this._container);
		L.DomEvent.addListener(this._form, 'submit', this._geocode, this);

		if (this.options.collapsed) {
			L.DomEvent.addListener(this._container, 'mouseover', this._expand, this);
			L.DomEvent.addListener(this._container, 'mouseout', this._collapse, this);

			this._layersLink = L.DomUtil.create('a', L.Control.OSMGeocoder.CLASS_NAME + '-toggle', this._container);
			this._layersLink.href = '#';

			L.DomEvent.addListener(this._layersLink, L.Browser.touch ? 'click' : 'focus', this._expand, this);

			this._map.on('movestart', this._collapse, this);
		} else {
			this._expand();
		}

		this._container.appendChild(this._form);

		return this._container;
	},

	_geocode : function (event) {
        var XMLHttpFactories = [
                function () {
                    return new XMLHttpRequest();
                },
                function () {
                    return new ActiveXObject("Msxml2.XMLHTTP");
                },
                function () {
                    return new ActiveXObject("Msxml3.XMLHTTP");
                },
                function () {
                    return new ActiveXObject("Microsoft.XMLHTTP");
                }
            ],
            sendRequest = function (url, callback, context) {
                var req = createXMLHTTPObject();
    
                context = (!context) ? window : context;
    
                if (!req) {
                    return;
                }
    
                req.open('GET', url, true);
    
                req.onreadystatechange = function () {
                    if (req.readyState != 4) {
                        return;
                    }
    
                    if (req.status != 200 && req.status != 304) {
                        return;
                    }
    
                    callback.call(context, req);
                };
    
                if (req.readyState == 4) {
                    return;
                }
    
                req.send();
            },
            
            createXMLHTTPObject = function () {
                var i,
                    xmlhttp = false,
                    length = XMLHttpFactories.length;
    
                for (i = 0; i < length; ++i) {
                    try {
                        xmlhttp = XMLHttpFactories[i]();
                    }
                    catch (e) {
                        continue;
                    }
                    break;
                }
    
                return xmlhttp;
            },
            params = {
                q:      this._input.value,
                format: 'json'
            };
            
        if (typeof this.options.email === 'string') {
			params.email = this.options.email;
        }
        
        if (this.options.bounds instanceof L.LatLngBounds) {
            params.viewbox = this.options.bounds.toBBoxString();
            params.bounded = 1;
        }

        L.DomEvent.preventDefault(event);
        sendRequest('http://nominatim.openstreetmap.org/search' + L.Util.getParamString(params),
                    this._callback,
                    this);

        this._input.value = '';
	},
    
    _callback : function (result) {
        this.options.callback.call(this, JSON.parse(result.response));
    },

	_expand: function () {
		L.DomUtil.addClass(this._container, L.Control.OSMGeocoder.CLASS_NAME + '-expanded');
	},

	_collapse: function () {
		L.DomUtil.removeClass(this._container, L.Control.OSMGeocoder.CLASS_NAME + '-expanded');
	}
});

L.Control.OSMGeocoder.CLASS_NAME = 'leaflet-control-geocoder';