#!/usr/bin/env python

import pika
import datetime
import json


def sendmessageParcel(id, shippingAddressLatitude, shippingAddressLongitude, weight, volume, loadingTime, downloadTime, productType,
                      shippingRate, status,time_max , time_min):
    now = datetime.datetime.now()
    if now.hour % 2 == 0:
        queque_name = 'Backhaul1'
    else:
        queque_name = 'Backhaul2'
    msj = {'typeMessage': 'parcel','id': id, 'shippingAddressLatitude': shippingAddressLatitude,
           'shippingAddressLongitude': shippingAddressLongitude,
           'weight': weight, 'volume': volume, 'loadingTime': loadingTime, 'downloadTime': downloadTime,
           'productType': productType, 'shippingRate': shippingRate, 'status':status, 'time_min': time_min, 'time_max': time_max}
    msjason = json.dumps(msj)
    connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()
    channel.queue_declare(queue=queque_name, durable=True)
    channel.basic_publish(exchange='queque_name', routing_key=queque_name, body=msjason, properties=pika.BasicProperties(delivery_mode = 2))
    connection.close()



def sendmessageTruck(id, garageLatitude, garageLongitude, isArmoredCabinet,
                     isRefrigeratedCabinet, truckTypeDescriptionType, truckTypeCost,
                     truckTypeMaximunWeight, maximunLoad, isOpenTruck, hasCabinet,
                     loadTypeGeneral, loadTypeDangerous, loadTypeValuable,
                     loadTypeLiveAnimal, loadTypePerishable,maximumVolume, status):

    now = datetime.datetime.now()
    if now.hour % 2 == 0:
        queque_name = 'Backhaul1'
    else:
        queque_name = 'Backhaul2'
    print(queque_name)
    connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))

    channel = connection.channel()

    channel.queue_declare(queue=queque_name, durable=True)
    msj = {'typeMessage': 'truck', 'id':id ,'Garage_Latitude': garageLatitude, 'Garage_Longitude':garageLongitude,
           'Is_Armored_Cabinet':isArmoredCabinet,'Is_Refrigerated_Cabinet': isRefrigeratedCabinet,
           'truckType_description_Type': truckTypeDescriptionType, 'truckType_cost': truckTypeCost,
           'truckType_maximun_Weight': truckTypeMaximunWeight,'Maximun_load': maximunLoad, 'Is_Open_Truck': isOpenTruck,
           'Has_Cabinet': hasCabinet,'Load_type_General': loadTypeGeneral,'Load_type_Dangerous': loadTypeDangerous,
            'Load_type_Valuable': loadTypeValuable,'Load_type_Live_Animal': loadTypeLiveAnimal,
           'load_type_Perishable': loadTypePerishable,'status':status, 'maximumVolume':maximumVolume,
           }
    msjason = json.dumps(msj)
    channel.basic_publish(exchange='', routing_key=queque_name, body=msjason, properties=pika.BasicProperties(delivery_mode = 2))
    connection.close()



